package pageObjects;

public interface HomePageElements {
	
	String exploreHeader = "explore-header";
	String avatar = "//div[@class='hui-globaluseritem__display-name']";
	String logOutbtn = "//a[@data-qa-id='webnav-usermenu-logout']";
}

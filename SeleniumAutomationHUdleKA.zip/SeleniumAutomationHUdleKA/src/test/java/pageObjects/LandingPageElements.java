package pageObjects;

public interface LandingPageElements {

	String loginBtn = "//a[@class='mainnav__item mainnav__item--expandable']";
	String loginHudlBtn = "//a[@data-qa-id='login-hudl']";
}

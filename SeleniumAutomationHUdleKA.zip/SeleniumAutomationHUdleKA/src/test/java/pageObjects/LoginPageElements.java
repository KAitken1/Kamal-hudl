package pageObjects;

public interface LoginPageElements {

	String email = "email";
	String password = "password";
	String continueBtn = "logIn";
}

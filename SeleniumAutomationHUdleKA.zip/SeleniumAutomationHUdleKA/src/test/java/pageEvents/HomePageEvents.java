package pageEvents;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseTest;
import pageObjects.HomePageElements;
import pageObjects.LoginPageElements;
import utilities.ElementFetch;

public class HomePageEvents extends BaseTest {
	
	ElementFetch ele = new ElementFetch();	
	
	public boolean isLoginSuccessful() {
        try {
        	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            By elementLocator = By.id("explore-header"); // Replace with the actual element locator
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
            return element.isDisplayed();
        } catch (NoSuchElementException e) {
            return false; // Element not found, login not successful
        }
	}

	public void logOut() throws InterruptedException 
	{
		Thread.sleep(5000);
		ele.getWebElement("XPATH", HomePageElements.avatar).click();
		Thread.sleep(1000);
		ele.getWebElement("XPATH", HomePageElements.logOutbtn).click();	
	}
}

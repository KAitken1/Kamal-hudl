package pageEvents;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseTest;
import pageObjects.LoginPageElements;
import utilities.ElementFetch;

public class LoginPageEvents extends BaseTest {
	
    private WebDriver driver;  // Define a WebDriver instance in the class

    public LoginPageEvents(WebDriver driver) {
        this.driver = driver;  // Initialise the driver instance in the constructor
    }

	ElementFetch ele = new ElementFetch();	

	public void setUsername(String username) 
	{
		ele.getWebElement("ID", LoginPageElements.email).sendKeys(username);
	}
	
	
	public void setPassword(String password) 
	{
		ele.getWebElement("ID", LoginPageElements.password).sendKeys(password);	
	}
	
	
	public void selectContinue() 
	{
		ele.getWebElement("ID", LoginPageElements.continueBtn).click();
	}
	
	public boolean isNotRecogErrorMessageDisplayed() throws InterruptedException {
	    try {
	        // Wait for the error message element to be visible
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	        By elementLocator = By.id("login-box");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
	        return true; // Element is found, so it exists
	    } catch (TimeoutException e) {
	        return false; // Element not found within the specified timeout, it doesn't exist
	    }
	}
	
	public boolean isRequiredFieldsErrorMessageDisplayed() throws InterruptedException {
	    try {
	        // Wait for the error message element to be visible
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	        By elementLocator = By.xpath("//p[text()=\"Please fill in all of the required fields\"]");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
	        return true; // Element is found, so it exists
	    } catch (TimeoutException e) {
	        return false; // Element not found within the specified timeout, it doesn't exist
	    }
	}
	
	public boolean isTooManyLoginMessageDisplayed() throws InterruptedException {
	    try {
	        // Wait for the error message element to be visible
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	        By elementLocator = By.xpath("//p[text()='Too many logins with the same username or email.']");
	        wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
	        return true; // Element is found, so it exists
	    } catch (TimeoutException e) {
	        return false; // Element not found within the specified timeout, it doesn't exist
	    }
	} 

	public void clickContinueMultipleTimesAndCheckAlert(int numberOfClicks) throws InterruptedException {
	    for (int i = 0; i < numberOfClicks; i++) {
	    	Thread.sleep(5000);
	        selectContinue(); 
	    }
	}
}

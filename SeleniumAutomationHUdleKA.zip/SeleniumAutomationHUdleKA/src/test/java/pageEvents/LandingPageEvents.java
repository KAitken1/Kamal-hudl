package pageEvents;

import pageObjects.LandingPageElements;
import utilities.ElementFetch;

public class LandingPageEvents {
	ElementFetch ele = new ElementFetch();
	public void signInButton() throws InterruptedException
	{
		ele.getWebElement("XPATH", LandingPageElements.loginBtn).click();
		Thread.sleep(2000);
		ele.getWebElement("XPATH", LandingPageElements.loginHudlBtn).click();
	}
}

package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;

public class ReadXLSdata {

    @DataProvider(name = "testdata")
    public Object[][] getData(Method m) throws EncryptedDocumentException, IOException {
        String excelSheetName = "positiveSignIn"; // The sheet name in your Excel file

        File f = new File(System.getProperty("user.dir") + "/excel/testdata.xlsx");
        FileInputStream fis = new FileInputStream(f);
        Workbook wb = WorkbookFactory.create(fis);
        Sheet sheetName = wb.getSheet(excelSheetName);

        DataFormatter format = new DataFormatter();

        int totalRows = sheetName.getLastRowNum();
        int totalCols = sheetName.getRow(0).getLastCellNum();

        Object[][] testData = new Object[totalRows][totalCols];

        for (int i = 1; i <= totalRows; i++) {
            Row row = sheetName.getRow(i);
            String scenario = format.formatCellValue(row.getCell(0));
            String username = format.formatCellValue(row.getCell(1));
            String password = format.formatCellValue(row.getCell(2));

            testData[i - 1][0] = scenario;
            testData[i - 1][1] = username;
            testData[i - 1][2] = password;
        }

        return testData;
    }
}

package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pageEvents.LandingPageEvents;
import pageEvents.LoginPageEvents;
import utilities.ReadXLSdata;
import pageEvents.HomePageEvents;

public class NegativeLoginCase extends BaseTest {
    private BaseTest baseTest = new BaseTest();
	LandingPageEvents landingPage = new LandingPageEvents();
	LoginPageEvents loginPage = new LoginPageEvents(baseTest.getDriver());
	HomePageEvents homePage = new HomePageEvents();
	
	/**
	 * Test for an unsuccessful login with a invalid username.
	 * @param scenario A scenario identifier.
	 * @param username The user's email address.
	 * @param password The user's password.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void InvalidUsername(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("InvalidUsername")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.setPassword(password);
			loginPage.selectContinue();
			Assert.assertTrue(loginPage.isNotRecogErrorMessageDisplayed(), "We don't recognize that email and/or password");  
		}
	}

	/**
	 * Test for an unsuccessful login with a invalid password.
	 * With a correct a username
	 * @param scenario A scenario identifier.
	 * @param username The user's email address.
	 * @param password The user's password.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void InvalidPassword(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("InvalidPassword")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.setPassword(password);
			loginPage.selectContinue();
			//Assert.assertTrue(loginPage.isNotRecogErrorMessageDisplayed(), "We don't recognize that email and/or password");        
		}
	}

	/**
	 * Test for an invalid username and password .
	 * This test checks if an error message is appears when the username field is empty.
	 * @param scenario A scenario identifier.
	 * @param email address for user.
	 * @param password for user.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void InvalidLogin(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("InvalidLogin")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.setPassword(password);
			loginPage.selectContinue();
			Assert.assertTrue(loginPage.isNotRecogErrorMessageDisplayed(), "We don't recognize that email and/or password");  
		}
	}
	
}

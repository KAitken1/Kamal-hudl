package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pageEvents.LandingPageEvents;
import pageEvents.LoginPageEvents;
import utilities.ReadXLSdata;
import pageEvents.HomePageEvents;

public class PositiveLoginCase extends BaseTest {
    private BaseTest baseTest = new BaseTest();
	LandingPageEvents landingPage = new LandingPageEvents();
	LoginPageEvents loginPage = new LoginPageEvents(baseTest.getDriver());
	HomePageEvents homePage = new HomePageEvents();
	
	/**
	 * Test for a successful login with valid credentials.
	 * This test checks if a user can log in successfully with valid credentials.
	 * @param scenario, A scenario identifier.
	 * @param username, The user's email address.
	 * @param password, The user's password.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void ValidCredentials(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("ValidSignIn")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.setPassword(password);
			loginPage.selectContinue();
			Assert.assertTrue(homePage.isLoginSuccessful(), "Login was successful"); 
		}       
	}

	/**
	 * Test for a successful login with a leading space.
	 * @param scenario A scenario identifier.
	 * @param username The user's email address.
	 * @param password The user's password.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void LeadingSpaceInUserName(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("TrailingSpace")) {
			landingPage.signInButton();
			loginPage.setUsername(username + "  ");
			loginPage.setPassword(password);
			loginPage.selectContinue();
			Assert.assertTrue(homePage.isLoginSuccessful(), "Login was successful");        
		}
	}

	/**
	 * Check that the login is case insensitive.
	 * This test checks whether a user can log in successfully with valid credentials.
	 * @param scenario A scenario identifier.
	 * @param username The user's email address.
	 * @param password The user's password.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void CaseInsensitiveWithUsername(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("CaseInset")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.setPassword(password);
			loginPage.selectContinue();
			Assert.assertTrue(homePage.isLoginSuccessful(), "Login was successful");        }
	}
	
	
}

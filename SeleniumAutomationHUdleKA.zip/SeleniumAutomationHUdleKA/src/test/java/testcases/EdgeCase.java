package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pageEvents.LandingPageEvents;
import pageEvents.LoginPageEvents;
import utilities.ReadXLSdata;
import pageEvents.HomePageEvents;

public class EdgeCase extends BaseTest {
    private BaseTest baseTest = new BaseTest();
	LandingPageEvents landingPage = new LandingPageEvents();
	LoginPageEvents loginPage = new LoginPageEvents(baseTest.getDriver());
	HomePageEvents homePage = new HomePageEvents();
	
	/**
	 * Test for an unsuccessful login with a empty username.
	 * This test checks if an error message is appears when the username field is empty.
	 * @param scenario A scenario identifier.
	 * @param email address for user.
	 * @param password for user.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void EmptyUsername(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("EmptyUsername")) {
			landingPage.signInButton();
			loginPage.setPassword(password);
			loginPage.selectContinue();
			Assert.assertTrue(loginPage.isRequiredFieldsErrorMessageDisplayed(), "Please fill in all of the required fields");  
		}
	}

	/**
	 * Test for an unsuccessful login with a empty password.
	 * This test checks if an error message is appears when the password field is empty.
	 * @param scenario A scenario identifier.
	 * @param email address for user.
	 * @param password for user.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void EmptyPassword(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("EmptyPassword")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.selectContinue();
			Assert.assertTrue(loginPage.isRequiredFieldsErrorMessageDisplayed(), "We don't recognize that email and/or password");  
		}
	}

	/**
	 * Test for an unsuccessful login with a empty username and password.
	 * This test checks if an error message is appears when the both fields empty.
	 * @param scenario A scenario identifier.
	 * @param email address for user.
	 * @param password for user.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void EmptyLogin(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("EmptyLogin")) {
			landingPage.signInButton();
			loginPage.selectContinue();
			Assert.assertTrue(loginPage.isRequiredFieldsErrorMessageDisplayed(), "We don't recognize that email and/or password");  
		}
	}

	/**
	 * Test for multiple login attempts alerting in a "Too many logins with the same username or email" message.
	 * Test to see login systems handles multiple attempts before displaying message
	 * @param scenario A scenario identifier.
	 * @param username The email address for the user.
	 * @param password The user's password.
	 * @throws InterruptedException If there's an interruption during the test execution.
	 */

	@Test(dataProvider = "testdata", dataProviderClass = ReadXLSdata.class)
	public void MultipleLoginAttempts(String scenario, String username, String password) throws InterruptedException {
		if (scenario.equals("InvalidPassword")) {
			landingPage.signInButton();
			loginPage.setUsername(username);
			loginPage.setPassword(password);
			loginPage.clickContinueMultipleTimesAndCheckAlert(10);
			Assert.assertTrue(loginPage.isTooManyLoginMessageDisplayed(), "Too many logins with the same username or email.");  
		}
	}
}
   